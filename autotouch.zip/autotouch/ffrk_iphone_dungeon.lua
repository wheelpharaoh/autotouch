-- constants
wait_long = 15;
wait_medium = 10;
wait_short = 5;
wait_quick = 2;
sec_sleep = 16000;
app_id = 'com.dena.west.FFRK';
--

-- env_coor (ipad)
ipad_coor_btn_splash_play = {788, 1512};
ipad_coor_btn_home_dungeon_event = {1121, 1337};
ipad_coor_btn_dungeon_event_banner = {742, 446}; -- y * 400
ipad_coor_btn_dungeon_event_banner_pixels = 400;
ipad_coor_btn_dungeon_event_banner_pixels_x = 742;
ipad_coor_btn_dungeon_event_banner_pixels_y = 446;
ipad_coor_btn_dungeon_event_difficulty = {935, 560}; -- y * 300; limit 5 of 6, (easy/normal/hard/heroic/+/++)
ipad_coor_btn_dungeon_event_difficulty_pixels = 300;
ipad_coor_btn_dungeon_event_difficulty_pixels_x = 935;
ipad_coor_btn_dungeon_event_difficulty_pixels_y = 560;
ipad_coor_btn_dungeon_difficulty_enter = {1056, 1856};
ipad_coor_btn_dungeon_difficulty_party_members_next = {782, 1894};
ipad_coor_btn_dungeon_difficulty_party_rw_go = {769, 1884};
ipad_coor_btn_dungeon_level = {485, 1120}; -- 485*1120->1042*1249->485*1120
ipad_coor_btn_dungeon_level_x1 = 485;
ipad_coor_btn_dungeon_level_y1 = 1120;
ipad_coor_btn_dungeon_level_x2 = 1042;
ipad_coor_btn_dungeon_level_y2 = 1249;
ipad_coor_btn_dungeon_level_beginbattle = {1057, 1321};
-- ipad_coor_btn_battle_auto = {245, 1525};
ipad_coor_btn_battle_skip = {1225, 1457};
ipad_coor_btn_battle_command = {221, 1830}; -- x * 250, (attack/defend/ability/ability(2)/SB)
ipad_coor_btn_battle_command_pixels = 250;
ipad_coor_btn_battle_command_pixels_x = 221;
ipad_coor_btn_battle_command_pixels_y = 1830;
ipad_coor_btn_battle_results_score_next = {788, 1834};
ipad_coor_btn_battle_results_exp_next = {770, 1835};
ipad_coor_btn_popup_next = {528, 1572};
--
-- env_assets (ipad)
ipad_img_ui_home = "images/ffrk_ipad_ui_home.bmp"; --screenshot("images/ffrk_ipad_ui_home.bmp", {1206, 524, 240, 110}); -- {1196, 514, 250, 120}
ipad_coor_ui_home = {1196, 514, 250, 120};

ipad_img_ui_dungeon = "images/ffrk_ipad_ui_dungeon.bmp";
ipad_coor_ui_dungeon = {1017,120,110,120};

ipad_img_ui_dungeon_battle = "images/ffrk_ipad_ui_battle.bmp"; --screenshot("images/ffrk_ipad_ui_battle.bmp", {124, 37, 80, 20}); -- {114, 27, 90, 30}
ipad_coor_ui_dungeon_battle = {114, 27, 90, 30};  

ipad_img_ui_dungeon_battle_results = "images/ffrk_ipad_ui_battle_results.bmp"; --screenshot("images/ffrk_ipad_ui_battle_results.bmp", {500, 1780, 530, 130}); -- {490, 1770, 540, 140}
ipad_coor_ui_dungeon_battle_results = {490, 1770, 540, 140};

ipad_img_ui_dungeon_difficulty = "images/ffrk_ipad_ui_dungeon_difficulty.bmp";
ipad_coor_ui_dungeon_difficulty = {432, 266, 320, 100};

ipad_img_popup_item_rare = "images/ffrk_ipad_popup_item_rare.bmp";
ipad_coor_popup_item_rare = {488, 1512, 540, 130};
--

-- env_coor (iphone)
iphone_coor_btn_splash_play = {364, 1033};
iphone_coor_btn_home_dungeon_event = {524, 864};
iphone_coor_btn_dungeon_event_banner = {384, 239};
iphone_coor_btn_dungeon_event_banner_pixels = 200; -- y-axis
iphone_coor_btn_dungeon_event_banner_pixels_x = 384;
iphone_coor_btn_dungeon_event_banner_pixels_y = 239;
iphone_coor_btn_dungeon_event_difficulty = {438, 314};
iphone_coor_btn_dungeon_event_difficulty_pixels = 130; -- y-axis
iphone_coor_btn_dungeon_event_difficulty_pixels_x = 438;
iphone_coor_btn_dungeon_event_difficulty_pixels_y = 314;
iphone_coor_btn_dungeon_difficulty_enter = {500, 1132};
iphone_coor_btn_dungeon_difficulty_party_members_next = {362, 1250};
iphone_coor_btn_dungeon_difficulty_party_rw_go = {366, 1249};
iphone_coor_btn_dungeon_level = {189, 688}; -- 
iphone_coor_btn_dungeon_level_pixels = 0; -- 189 688 -> 496 532 -> 191 367, x+-300, y-150
iphone_coor_btn_dungeon_level_pixels_x1 = 189;
iphone_coor_btn_dungeon_level_pixels_y1 = 688;
iphone_coor_btn_dungeon_level_pixels_x2 = 570;
iphone_coor_btn_dungeon_level_pixels_y2 = 767;
iphone_coor_btn_dungeon_level_beginbattle = {522, 832};
iphone_coor_btn_battle_skip = {639, 1012};
iphone_coor_btn_battle_command = {62, 1212};
iphone_coor_btn_battle_command_pixels = 135;
iphone_coor_btn_battle_command_pixels_x = 62;
iphone_coor_btn_battle_command_pixels_y = 1212;
iphone_coor_btn_battle_results_score_next = {365, 1118};
iphone_coor_btn_battle_results_exp_next = {365, 1118};
iphone_coor_btn_popup_next = {367, 822};
--
-- env_assets (iphone)
iphone_img_ui_home = "images/ffrk_iphone_ui_home.bmp"; --screenshot("images/ffrk_iphone_ui_home.bmp", {620, 291, 125, 60});
iphone_coor_ui_home = {610, 281, 135, 70};
  
iphone_img_ui_dungeon = "images/ffrk_iphone_ui_dungeon.bmp"; -- {518, 75, 50, 50}
iphone_coor_ui_dungeon = {508, 65, 60, 60};

iphone_img_popup_dungeon_level = "images/ffrk_iphone_popup_dungeon_level.bmp"; -- {518, 75, 50, 50}
iphone_coor_popup_dungeon_level = {508, 65, 60, 60};

iphone_img_ui_dungeon_difficulty = "images/ffrk_iphone_ui_dungeon_difficulty.bmp"; -- {246, 154, 120, 40} -- other: {470, 154, 230, 20}
iphone_coor_ui_dungeon_difficulty = {470, 153, 250, 40};

iphone_img_ui_dungeon_battle = "images/ffrk_iphone_ui_dungeon_battle.bmp"; -- {12, 10, 60, 20}
iphone_coor_ui_dungeon_battle = {2, 0, 70, 30};  

iphone_img_ui_dungeon_battle_results = "images/ffrk_iphone_ui_dungeon_battle_results.bmp"; --OLD:{230, 1087, 300, 60}; --NEW:{230, 1090, 290, 50}
iphone_coor_ui_dungeon_battle_results = {316, 1090, 120, 70}; -- OLD: {220, 1077, 310, 70}; NEW:{220, 1080, 300, 60}

iphone_img_popup_item_rare = "images/ffrk_iphone_popup_item_rare.bmp"; -- {226, 797, 300, 60};
iphone_coor_popup_item_rare = {223, 797, 310, 70}; -- NEW:{223,797, 310, 70} OLD:{216, 787, 310, 70}


-- config
-- btn coors
coor_splash_btn_play = iphone_coor_btn_splash_play;
coor_home_btn_dungeon_event = iphone_coor_btn_home_dungeon_event;
coor_dungeon_event_btn_banner = iphone_coor_btn_dungeon_event_banner;
coor_dungeon_event_btn_banner_pixels = iphone_coor_btn_dungeon_event_banner_pixels;
coor_dungeon_event_btn_banner_pixels_x = iphone_coor_btn_dungeon_event_banner_pixels_x;
coor_dungeon_event_btn_banner_pixels_y = iphone_coor_btn_dungeon_event_banner_pixels_y;
coor_dungeon_event_btn_difficulty = iphone_coor_btn_dungeon_event_difficulty;
coor_dungeon_event_btn_difficulty_pixels = iphone_coor_btn_dungeon_event_difficulty_pixels;
coor_dungeon_event_btn_difficulty_pixels_x = iphone_coor_btn_dungeon_event_difficulty_pixels_x;
coor_dungeon_event_btn_difficulty_pixels_y = iphone_coor_btn_dungeon_event_difficulty_pixels_y;
coor_dungeon_difficulty_btn_enterdungeon = iphone_coor_btn_dungeon_difficulty_enter;
coor_dungeon_party_members_btn_next = iphone_coor_btn_dungeon_difficulty_party_members_next;
coor_dungeon_party_rw_btn_go = iphone_coor_btn_dungeon_difficulty_party_rw_go;
coor_dungeon_btn_level = iphone_coor_btn_dungeon_level;
coor_dungeon_btn_level_x1 = iphone_coor_btn_dungeon_level_pixels_x1;
coor_dungeon_btn_level_y1 = iphone_coor_btn_dungeon_level_pixels_y1;
coor_dungeon_btn_level_x2 = iphone_coor_btn_dungeon_level_pixels_x2;
coor_dungeon_btn_level_y2 = iphone_coor_btn_dungeon_level_pixels_y2;
coor_dungeon_level_popup_btn_beginbattle = iphone_coor_btn_dungeon_level_beginbattle;
coor_dungeon_battle_btn_skip = iphone_coor_btn_battle_skip;
coor_dungeon_battle_btn_command = iphone_coor_btn_battle_command;
coor_dungeon_battle_btn_command_pixels = iphone_coor_btn_battle_command_pixels; -- pixel-count between command-image centers
coor_dungeon_battle_btn_command_pixels_x = iphone_coor_btn_battle_command_pixels_x;
coor_dungeon_battle_btn_command_pixels_y = iphone_coor_btn_battle_command_pixels_y;
coor_dungeon_battle_results_score_btn_next = iphone_coor_btn_battle_results_score_next;
coor_dungeon_battle_results_exp_btn_next = iphone_coor_btn_battle_results_exp_next;
coor_dungeon_battle_results_loot_popup_btn_ok = iphone_coor_btn_popup_next;
--
-- UI assets
home_i = iphone_img_ui_home;
home_c = iphone_coor_ui_home;

dungeon_i = iphone_img_ui_dungeon;
dungeon_c = iphone_coor_ui_dungeon;

popup_dungeon_level_i = iphone_img_popup_dungeon_level;
popup_dungeon_level_c = iphone_coor_popup_dungeon_level;

dungeon_difficulty_i = iphone_img_ui_dungeon_difficulty;
dungeon_difficulty_c = iphone_coor_ui_dungeon_difficulty;
  
battle_i = iphone_img_ui_dungeon_battle;
battle_c = iphone_coor_ui_dungeon_battle;

battle_results_i = iphone_img_ui_dungeon_battle_results;
battle_results_c = iphone_coor_ui_dungeon_battle_results;

popup_item_rare_i = iphone_img_popup_item_rare;
popup_item_rare_c = iphone_coor_popup_item_rare;
--
-- settings
dungeon_event_num = 3;
dungeon_event_difficulty = 1; -- (daily-dungeon: 1-6, 7-12)
dungeon_event_levels = 3;

dungeon_realm_num = 0; -- not work
dungeon_realm_difficulty = 0; -- not work
dungeon_realm_levels = 0; -- not work

dungeon_type = 'event'; -- event/realm;
dungeon_num = dungeon_event_num; -- 1-../1-15
dungeon_difficulty = dungeon_event_difficulty; -- 1-12/1-..
dungeon_levels = dungeon_event_levels; -- 1-..
runs = 1;
--

-- serialize funcs
function table.val_to_str ( v )
  if "string" == type( v ) then
    v = string.gsub( v, "\n", "\\n" )
    if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
      return "'" .. v .. "'"
    end
    return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
  else
    return "table" == type( v ) and table.tostring( v ) or
      tostring( v )
  end
end

function table.key_to_str ( k )
  if "string" == type( k ) and string.match( k, "^[_%a][_%a%d]*$" ) then
    return k
  else
    return "[" .. table.val_to_str( k ) .. "]"
  end
end

function table.tostring( tbl )
  local result, done = {}, {}
  for k, v in ipairs( tbl ) do
    table.insert( result, table.val_to_str( v ) )
    done[ k ] = true
  end
  for k, v in pairs( tbl ) do
    if not done[ k ] then
      table.insert( result,
        table.key_to_str( k ) .. "=" .. table.val_to_str( v ) )
    end
  end
  return "{" .. table.concat( result, "," ) .. "}"
end

-- Implement a unpack function
function unpack (t, i)
  i = i or 1
  if t[i] ~= nil then
    return t[i], unpack(t, i + 1)
  end
end

-- Implement a tap function
function tap(x, y)
    touchDown(0, x, y);
    usleep(sec_sleep);
    touchUp(0, x, y);
end

-- Implement a tap_then_wait function
function tap_wait_short(coor)
  	local x, y = unpack(coor);
	log(string.format("Tapping (short) x:%s, y:%s", x, y));  
    touchDown(0, x, y);
    usleep(sec_sleep);
    touchUp(0, x, y);
    usleep(sec(wait_short));  
end

function tap_wait_quick(coor)
  	local x, y = unpack(coor);
	log(string.format("Tapping (quick) x:%s, y:%s", x, y));
    touchDown(0, x, y);
    usleep(sec_sleep);
    touchUp(0, x, y);
    usleep(sec(wait_quick));  
end

-- Implement a conv_sec_us function
function sec(x)
  local us = x * 1000000;
  return us
end

-- Implement map_num_to_event_banner function
function event(banner)
  local x = coor_dungeon_event_btn_banner_pixels_x;
  local y1 = coor_dungeon_event_btn_banner_pixels_y;
  local y = (y1 + ((banner - 1) * coor_dungeon_event_btn_banner_pixels) );
  log(string.format("Event banner computed x:%s, y:%s", x, y));
  return {x, y}
end

-- Implement map_num_to_difficulty_banner function
function difficulty(d)
  local x = coor_dungeon_event_btn_difficulty_pixels_x;
  local y1 = coor_dungeon_event_btn_difficulty_pixels_y;
  
  if d > 5 then
    -- difficult >5, do a drag/slide up
 
    for i=1,d-5,1 do
      local y = (y1 + ((2 - 1) * coor_dungeon_event_btn_difficulty_pixels) );
      touchDown(0, x, y);
      usleep(16000);      
      for m=1,coor_dungeon_event_btn_difficulty_pixels,10 do	
          touchMove(0, x, y - m);
          usleep(16000);
      end
      touchUp(0, x, y - (i * coor_dungeon_event_btn_difficulty_pixels));
      usleep(16000); 
    end
    
    y = (y1 + ((5 - 1) * coor_dungeon_event_btn_difficulty_pixels) ); -- only 5 difficulties are selectable at a time in the UI
    tap(x,y);
    
    return {x, y}
  else
	local y = (y1 + ((d - 1) * coor_dungeon_event_btn_difficulty_pixels) );
    tap(x,y);
    return {x, y}
  end
end

-- Implement get_dungeon_level function
function level(l)
  log(string.format('next level to progress to: %s', l));
  local x1 = coor_dungeon_btn_level_x1;
  local y1 = coor_dungeon_btn_level_y1;
  local x2 = coor_dungeon_btn_level_x2;
  local y2 = coor_dungeon_btn_level_y2;
  
  if (l % 2 == 0) then
	return {x2, y2}
  else
	return {x1, y1}
  end
end

-- Implement get_battle_command function
function command(c)
  local x1 = coor_dungeon_battle_btn_command_pixels_x;
  local x = (x1 + ((c - 1) * coor_dungeon_battle_btn_command_pixels) );
  local y = coor_dungeon_battle_btn_command_pixels_y;
  return {x, y}
end

-- UI-location function
-- This can return false-positives if the region size is less than that of the reference image size
-- Sometimes you will need to run this function against the entire region and return 1 coor to get the ideal reference point
function in_ui(ui_img, ui_region)
  --log(string.format('checking if in %s at %s', ui_img, table.tostring(ui_region)));
  
  local result = findImage(ui_img, 0, 0.1, nil, ui_region);
  --log("debug: result - ".. table.concat(result, " "));
  screenshot('images/ffrk_debug_img.bmp', ui_region);
  
  if (table.tostring(result) == table.tostring(ui_region)) then
    log("findImage result unusable... may need to run collectgarbage()");
    log("return false");
    return false
  end
  
  --log(string.format("serialized in_ui findImage-result: %s", table.tostring(result)));  
 
  if next(result) ~= nil then
    log(string.format("Found %s image", ui_img));
    for i, v in pairs(result) do
	    --log(string.format("Found rect at: x:%f, y:%f", ui_img, v[1], v[2]));
    end
	return true
  else
    log(string.format("Did NOT find %s", ui_img));
    return false
  end       
end


-- main
while ( not in_ui(home_i, home_c) )
do
  -- Run FFRK
  appRun(app_id);

  -- sleep 15 seconds
  usleep(sec(wait_quick));

  -- tap 'play'
  tap_wait_short(coor_splash_btn_play);
end
collectgarbage();

-- tap '(event) dungeon'
tap_wait_quick(coor_home_btn_dungeon_event);

-- tap (event) dungeon banner 
tap_wait_quick(event(dungeon_num));

-- dungeon_difficulty loop
log('Checking dungeon_difficulty loop');  
while ( in_ui(dungeon_difficulty_i, dungeon_difficulty_c) and runs ~= 0)
do
  log(string.format('runs to complete: %s', runs));
  log('entering dungeon_difficulty loop');    
  -- tap event dungeon difficulty 
  tap_wait_quick(difficulty(dungeon_difficulty));
  
  -- tap 'enter dungeon'
  tap_wait_quick(coor_dungeon_difficulty_btn_enterdungeon);

  -- tap 'party members,next'
  tap_wait_quick(coor_dungeon_party_members_btn_next);

  -- tap 'rw,go!'
  tap_wait_short(coor_dungeon_party_rw_btn_go);

  -- dungeon loop
  local l = 0;
  log('Checking dungeon loop');  
  while( in_ui(dungeon_i, dungeon_c) )  
  do
    log('entering dungeon loop');      
    l = l + 1;
    
    while( not in_ui(popup_dungeon_level_i, popup_dungeon_level_c) and not in_ui(battle_i, battle_c) )
    do
      -- tap level
      tap_wait_short(level(l));
	end
    
    while( in_ui(popup_dungeon_level_i, popup_dungeon_level_c) )
    do
      -- tap 'begin battle'
      -- TODO: add gem-refresh here
      tap_wait_short(coor_dungeon_level_popup_btn_beginbattle);

      --  tap '(cancel) auto'
      --tap_wait_short(coor_ipad_btn_battle_auto);

      -- it may be possible to get stuck here when the UI darkens for the begin-battle popup and the click is mis-timed, so
      -- TODO: check for 'now loading' or loop until we hit now-loading
      --usleep(sec(2));
    end

    log('Checking pre-dungeon_battle loop');     
    while( not in_ui(dungeon_i, dungeon_c) and not in_ui(dungeon_difficulty_i, dungeon_difficulty_c))
    do
      log('entering pre-dungeon_battle loop');      
      -- dungeon_battle loop
      log('Checking dungeon_battle loop');  
      while( in_ui(battle_i, battle_c) and not in_ui(battle_results_i, battle_results_c) and not in_ui(popup_item_rare_i, popup_item_rare_c) )
      do
        log('entering dungeon_battle loop');   
        -- tap command 3
        tap(unpack(command(3)));
        usleep(sec(1));

        -- tap command 4
        tap(unpack(command(4)));
        usleep(sec(1));
        
        -- tap 'Skip'
        -- TODO: add coordinates for tapping skip, due to running out of abilities
        tap(unpack(coor_dungeon_battle_btn_skip));
        usleep(sec(0.8));
        
      end

      -- dungeon_battle_results loop
      log('Checking dungeon_battle_results loop');  
      while ( in_ui(battle_results_i, battle_results_c) and not in_ui(battle_i, battle_c) )
      do
        log('entering dungeon_battle_results loop');      
        -- tap next
        tap(unpack(coor_dungeon_battle_results_score_btn_next));
        usleep(sec(1));    

        -- tap next
        tap(unpack(coor_dungeon_battle_results_exp_btn_next));
        usleep(sec(1));
      end    

      -- dungeon_battle_results_loot_popup_item_rare loop
      log('Checking dungeon_battle_results_loot_popup_item_rare loop');  
      while( in_ui(popup_item_rare_i, popup_item_rare_c))
      do
        log('entering dungeon_battle_results_loot_popup_item_rare loop');
        tap(unpack(coor_dungeon_battle_results_loot_popup_btn_ok));
        usleep(sec(1)); 
      end

      log('finished dungeon-level loop: ' .. tostring(l))
      collectgarbage();
    end
   end

  if ( (l * runs) % dungeon_levels == 0) then
    log(string.format('current-level: %s, dungeon-levels: %s, runs: %s, modulos: %s', l, dungeon_levels, runs, (l * runs) % dungeon_levels));
    runs = runs - 1;
    break
  else
    log(string.format('current-level: %s, dungeon-levels: %s, runs: %s, modulos: %s', l, dungeon_levels, runs, (l * runs) % dungeon_levels));
  end
  
end
-- (repeat: level->beginbattle->command->next->next)
  